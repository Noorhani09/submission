document.addEventListener('DOMContentLoaded', function() {
    const bookForm = document.getElementById('book-form');
    const titleInput = document.getElementById('title');
    const authorInput = document.getElementById('author');
    const yearInput = document.getElementById('year');
    const isCompleteInput = document.getElementById('isComplete');
    const unfinishedBookshelf = document.getElementById('unfinished-bookshelf');
    const finishedBookshelf = document.getElementById('finished-bookshelf');

    bookForm.addEventListener('submit', function(event) {
        event.preventDefault();
        
        const title = titleInput.value;
        const author = authorInput.value;
        const year = parseInt(yearInput.value); // Mengonversi input tahun ke tipe data number
        const isComplete = isCompleteInput.checked;

        const book = {
            id: +new Date(),
            title: title,
            author: author,
            year: year,
            isComplete: isComplete
        };

        // Simpan buku ke localStorage
        const books = JSON.parse(localStorage.getItem('books')) || [];
        books.push(book);
        localStorage.setItem('books', JSON.stringify(books));

        // Tampilkan buku pada rak yang sesuai
        renderBook(book);

        // Reset formulir
        titleInput.value = '';
        authorInput.value = '';
        yearInput.value = '';
        isCompleteInput.checked = false;
    });

    // Fungsi untuk merender buku ke rak yang sesuai
    function renderBook(book) {
        const bookElement = document.createElement('div');
        bookElement.className = 'book';
        bookElement.innerHTML = `
            <h3>${book.title}</h3>
            <p>Penulis: ${book.author}</p>
            <p>Tahun: ${book.year}</p>
            <button class="delete-button">Hapus</button>
            <button class="status-button">${book.isComplete ? 'Belum Selesai Dibaca' : 'Selesai Dibaca'}</button>
        `;

        const deleteButton = bookElement.querySelector('.delete-button');
        deleteButton.addEventListener('click', function() {
            // Hapus buku dari localStorage
            const books = JSON.parse(localStorage.getItem('books')) || [];
            const updatedBooks = books.filter(b => b.id !== book.id);
            localStorage.setItem('books', JSON.stringify(updatedBooks));

            // Hapus buku dari rak
            bookElement.remove();
        });

        const statusButton = bookElement.querySelector('.status-button');
        statusButton.addEventListener('click', function() {
            // Ubah status buku
            book.isComplete = !book.isComplete;
            
            if (book.isComplete) {
                // Hapus buku dari rak "Belum selesai dibaca"
                unfinishedBookshelf.removeChild(bookElement);

                // Tampilkan buku pada rak "Selesai dibaca"
                finishedBookshelf.appendChild(bookElement);
            } else {
                // Hapus buku dari rak "Selesai dibaca"
                finishedBookshelf.removeChild(bookElement);

                // Tampilkan buku pada rak "Belum selesai dibaca"
                unfinishedBookshelf.appendChild(bookElement);
            }

            // Perbarui status buku di localStorage
            const books = JSON.parse(localStorage.getItem('books')) || [];
            const updatedBooks = books.map(b => {
                if (b.id === book.id) {
                    b.isComplete = book.isComplete;
                }
                return b;
            });
            localStorage.setItem('books', JSON.stringify(updatedBooks));

            // Perbarui teks tombol status
            statusButton.textContent = book.isComplete ? 'Belum Selesai Dibaca' : 'Selesai Dibaca';
        });

        if (book.isComplete) {
            finishedBookshelf.appendChild(bookElement);
        } else {
            unfinishedBookshelf.appendChild(bookElement);
        }
    }

    // Memuat buku-buku dari localStorage saat halaman dimuat
    const books = JSON.parse(localStorage.getItem('books')) || [];
    books.forEach(renderBook);
});
